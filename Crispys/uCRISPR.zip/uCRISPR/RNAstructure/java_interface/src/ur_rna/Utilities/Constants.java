package ur_rna.Utilities;

public final class Constants {
    private Constants(){} //prevent instantiation
    public static final int OCTAL_RADIX=8;
    public static final int HEX_RADIX=16;
}
