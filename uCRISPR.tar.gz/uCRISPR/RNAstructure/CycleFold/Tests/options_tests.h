
#include "../options.h"


BOOST_AUTO_TEST_CASE(options_class)
{
    /*
     * this is no longer needed, now use RNAstructure parser
    char* normal_argv[] = {"loop-partition","test.seq","probs.txt"};
	options op = parser::parseCommandLine(3,normal_argv);
	BOOST_CHECK ( op.input_files[0] == "test.seq");
    */
}
