// This file is auto-generated during the RNAstructure Release Process.
// You can modify it manually, but any changes will be overwritten when a release is built.
// To make permanent changes, edit RNAstructure/RELEASE/resources/RNAstructureVersion.java.tpl

package ur_rna.RNAstructure;
/** Interface that contains constants related to the current RNAstructure Release information. */
public interface RNAstructureVersion {
    String VERSION = "6.4";
    String RELEASE_DATE = "December 8, 2021";
}
