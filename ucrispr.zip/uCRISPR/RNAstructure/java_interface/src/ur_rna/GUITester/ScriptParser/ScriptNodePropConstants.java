package ur_rna.GUITester.ScriptParser;

public interface ScriptNodePropConstants
{
  int OPERATION = 0;
  int RHS = 1;
  int LHS = 2;
  int PRIMITIVE = 3;
}